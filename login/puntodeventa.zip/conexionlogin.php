<!-- 
Creado por Luisetfree & tecnosetfree
Web: http://luisetfree.over-blog.es
Facebook:https://www.facebook.com/tecnosetfree/
Twitter: @tecnosetfree
Apoyanos con tus visitas y comentarios en nuestras redes sociales para seguir avanzando y traer contenido de calidad.

 -->
<!-- ingresa todos los datos referentes a tu conexion de base de datos
de esta forma solo tendras que modificar un solo archivo -->
<?php
$host_db = 'localhost';
 $user_db = 'root';
 $pass_db = '';
 $db_name = 'fantastic';
 $tbl_name = 'usuarios';
?>