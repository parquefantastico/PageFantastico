 <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Creado por WolfGangE
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2019 <a href="#">Fantastico</a>.</strong> Todos los derechos reservados.
  </footer>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
  immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
</body>
</html>