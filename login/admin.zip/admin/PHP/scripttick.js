window.print();
function regresar() {
 location.href="../index.php?f=1";
};
