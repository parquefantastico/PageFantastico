<!DOCTYPE html>
<html>
<head>
	<title> Fantastico</title>


	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
	
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
<script src="sweetalert2.min.js"></script>
<link rel="stylesheet" href="sweetalert2.min.css">
</head>
<body>


<a class="btn btn-primary btn-lg" href='javascript:;' onclick="ayudame();" role="button">
  NO ME TOQUES &raquo;
</a>



<script type="text/javascript">
 



 
Swal.fire({
  title: '<h1> NYANYANYANYA</h1>',
   allowOutsideClick: false,
   allowEscapeKey: false,
  showConfirmButton: false,
  width: 600,
  padding: '1em',
  background: '#fff url(/images/trees.png)',
  backdrop: `
    rgba(0,0,123,0.4)
    url("C93.gif")
    center left
   
  `
})

</script>
	




</body>
</html>